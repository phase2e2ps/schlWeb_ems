<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Records</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --primary:#2563eb;
  --dark:#0f172a;
  --bg:#f1f5f9;
  --card:#ffffff;
  --text:#1e293b;
  --muted:#64748b;
  --border:#e2e8f0;
}

*{
  box-sizing:border-box;
  font-family:'Inter',sans-serif;
  margin:0;
  padding:0;
}

body{
  background:var(--bg);
}

/* Layout */
.wrapper{
  display:flex;
  height:100vh;
}

/* Sidebar */
.sidebar{
  width:260px;
  background:var(--dark);
  color:#fff;
  padding:20px;
  transition:.3s;
  overflow-y:auto;
}

.sidebar.collapsed{
  width:80px;
}

.sidebar h2{
  font-size:18px;
  margin-bottom:25px;
}

.menu-item{
  padding:12px;
  border-radius:8px;
  cursor:pointer;
  margin-bottom:6px;
  font-size:14px;
  transition:.2s;
}

.menu-item:hover{
  background:rgba(255,255,255,0.1);
}

.submenu{
  display:none;
  padding-left:15px;
}

.submenu div{
  padding:8px;
  font-size:13px;
  color:#cbd5e1;
  cursor:pointer;
}

.submenu div:hover{
  background:rgba(255,255,255,0.1);
}

.active + .submenu{
  display:block;
}

/* Main */
.main{
  flex:1;
  display:flex;
  flex-direction:column;
}

/* Topbar */
.topbar{
  background:var(--card);
  padding:15px 25px;
  border-bottom:1px solid var(--border);
  display:flex;
  justify-content:space-between;
  align-items:center;
}

.toggle{
  cursor:pointer;
  font-size:18px;
}

.role-select{
  padding:6px;
  border-radius:6px;
}

/* Content */
.content{
  padding:30px;
}

.card{
  background:var(--card);
  padding:20px;
  border-radius:12px;
  box-shadow:0 4px 15px rgba(0,0,0,0.05);
  cursor:pointer;
  transition:all .25s ease;
  position:relative;
  overflow:hidden;
}

.card:hover{
  transform:translateY(-5px);
  box-shadow:0 8px 25px rgba(0,0,0,0.08);
}

.card:active{
  transform:scale(.98);
}


.section{
  margin-top:30px;
}

.section h2{
  margin-bottom:15px;
}

.activity{
  background:var(--card);
  padding:15px;
  border-radius:10px;
  margin-bottom:10px;
  font-size:14px;
}

.menu-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.menu-item.active .arrow {
  transform: rotate(180deg);
}

.arrow {
  transition: 0.3s;
  font-size: 10px;
}

.submenu div {
  padding: 10px 15px;
  border-radius: 6px;
  margin: 2px 0;
  transition: 0.2s;
}

.submenu div:hover {
  background: var(--primary); /* Highlights the sub-item with your primary blue */
  color: white !important;
}

/* Main */
.main {
  flex: 1;
  display: flex;
  flex-direction: column;
}

/* Header */
.header {
  background: var(--card);
  padding: 18px 30px;
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header h1 {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
}

.user {
  font-size: 14px;
  color: var(--muted);
}

/* Content */
.content {
  padding: 30px;
}

/* Card */
.card {
  background: var(--card);
  padding: 25px;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.04);
  margin-bottom: 25px;
}

.card h3 {
  margin-top: 0;
  font-size: 16px;
  margin-bottom: 20px;
}

/* Search */
.search-bar {
  display: flex;
  gap: 10px;
}

.search-bar input {
  flex: 1;
}

/* Forms */
input, select {
  width: 100%;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid var(--border);
  font-size: 14px;
  transition: 0.2s;
}

input:focus, select:focus {
  border-color: var(--primary);
  outline: none;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
}

label {
  font-size: 13px;
  color: var(--muted);
  margin-bottom: 6px;
  display: block;
}

/* Two Columns */
.row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 25px;
}

/* Buttons */
button {
  padding: 10px 16px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  font-weight: 500;
  font-size: 14px;
  transition: 0.2s;
}

.btn-primary {
  background: var(--primary);
  color: #fff;
}

.btn-primary:hover {
  background: var(--primary-dark);
}

.btn-secondary {
  background: #e2e8f0;
}

.btn-success {
  background: var(--success);
  color: #fff;
}

.btn-dark {
  background: #1e293b;
  color: #fff;
}

.confirm-box {
  margin-top: 15px;
  padding: 12px;
  border-radius: 8px;
  background: #ecfdf5;
  color: var(--success);
  font-weight: 600;
  text-align: center;
}

/* Bottom Actions */
.actions {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

/* Responsive */
@media(max-width: 900px) {
  .row {
    grid-template-columns: 1fr;
  }
  .sidebar {
    display: none;
  }
}

</style>
</head>

<script>
// ----------------------------
// Mock Database
// ----------------------------
const students = [
  {
    id: "202600182",
    firstName: "John",
    lastName: "Doe",
    grade: "10",
    dob: "2010-05-12",
    section: "10-A"
  },
  {
    id: "202600183",
    firstName: "Jane",
    lastName: "Smith",
    grade: "9",
    dob: "2011-03-22",
    section: "9-B"
  }
];

const subjects = [
  { code: "M101", title: "Math 101" },
  { code: "S101", title: "Science 101" },
  { code: "E101", title: "English 101" }
];

// ----------------------------
// DOM Elements
// ----------------------------
const searchInput = document.querySelector(".search-bar input");
const searchBtn = document.querySelector(".search-bar button");

const firstNameInput = document.querySelector("input[placeholder='']");
const inputs = document.querySelectorAll("input");
const selects = document.querySelectorAll("select");

const studentIdInput = document.querySelectorAll("input")[4];
const gradeSelect = document.querySelectorAll("select")[0];
const sectionSelect = document.querySelectorAll("select")[1];

const subjectCodeSelect = document.querySelectorAll("select")[2];
const subjectTitleSelect = document.querySelectorAll("select")[3];

const slotInput = document.querySelector("input[type='number']");
const confirmBox = document.querySelector(".confirm-box");

const slipName = document.querySelector(".card:nth-child(3) p:nth-child(2)");
const slipId = document.querySelector(".card:nth-child(3) p:nth-child(3)");
const slipSection = document.querySelector(".card:nth-child(3) p:nth-child(4)");
const slipSubject = document.querySelector(".card:nth-child(3) p:nth-child(5)");

const confirmBtn = document.querySelector(".btn-primary");
const approveBtn = document.querySelector(".btn-success");
const finishBtn = document.querySelector(".btn-dark");
const printBtn = document.querySelector(".btn-dark");

// ----------------------------
// Populate Subject Dropdown
// ----------------------------
subjects.forEach(sub => {
  let option = document.createElement("option");
  option.value = sub.code;
  option.textContent = sub.code;
  subjectCodeSelect.appendChild(option);

  let option2 = document.createElement("option");
  option2.value = sub.title;
  option2.textContent = sub.title;
  subjectTitleSelect.appendChild(option2);
});

// ----------------------------
// Search Student
// ----------------------------
searchBtn.addEventListener("click", () => {
  const value = searchInput.value.trim();

  const student = students.find(
    s => s.id === value || s.firstName.toLowerCase() === value.toLowerCase()
  );

  if (!student) {
    alert("Student not found");
    return;
  }

  document.querySelectorAll("input")[0].value = student.firstName;
  document.querySelectorAll("input")[1].value = student.lastName;
  studentIdInput.value = student.id;
  gradeSelect.innerHTML = `<option>${student.grade}</option>`;
  sectionSelect.innerHTML = `<option>${student.section}</option>`;

  updateSlip();
});

// ----------------------------
// Sync Subject Title
// ----------------------------
subjectCodeSelect.addEventListener("change", () => {
  const selected = subjects.find(s => s.code === subjectCodeSelect.value);
  if (selected) {
    subjectTitleSelect.value = selected.title;
  }
  updateSlip();
});

// ----------------------------
// Slot Controls
// ----------------------------
slotInput.addEventListener("change", () => {
  if (slotInput.value < 0) slotInput.value = 0;
});

// ----------------------------
// Confirm Enrollment
// ----------------------------
confirmBtn.addEventListener("click", () => {
  if (slotInput.value <= 0) {
    alert("No slots available!");
    return;
  }

  confirmBox.textContent = "Enrollment Confirmed!";
  confirmBox.style.background = "#dbeafe";
  confirmBox.style.color = "#2563eb";

  slotInput.value = slotInput.value - 1;
  updateSlip();
});

// ----------------------------
// Approve Enrollment
// ----------------------------
approveBtn.addEventListener("click", () => {
  alert("Enrollment Approved!");
});

// ----------------------------
// Finish Enrollment
// ----------------------------
finishBtn.addEventListener("click", () => {
  alert("Enrollment Process Completed!");
  location.reload();
});

// ----------------------------
// Print Slip
// ----------------------------
printBtn.addEventListener("click", () => {
  window.print();
});

// ----------------------------
// Update Slip
// ----------------------------
function updateSlip() {
  const firstName = document.querySelectorAll("input")[0].value;
  const lastName = document.querySelectorAll("input")[1].value;

  slipName.innerHTML = `<strong>Name:</strong> ${firstName} ${lastName}`;
  slipId.innerHTML = `<strong>Student ID:</strong> ${studentIdInput.value}`;
  slipSection.innerHTML = `<strong>Section:</strong> ${sectionSelect.value}`;
  slipSubject.innerHTML = `<strong>Subject:</strong> ${subjectTitleSelect.value}`;
}

</script>

<body>

<div class="wrapper">

  <div class="sidebar" id="sidebar">

  <h2 onclick="location.reload()" style="cursor:pointer">EMS System</h2>

  <div class="menu-item" onclick="openSection('dashboard')">
    <i class="fa-solid fa-chart-line"></i> Dashboard
  </div>

  <div class="menu-item admin-only" onclick="toggleMenu(this)">
    User Management <span class="arrow">▾</span>
  </div>
  <div class="submenu admin-only">
    <div onclick="openSection('add-admin')">Add Admin</div>
    <div onclick="openSection('add-teacher')">Add Teacher</div>
    <div onclick="openSection('view-users')">View Users</div>
    <div onclick="openSection('assign-roles')">Assign Roles</div>
  </div>

  <div class="menu-item" onclick="toggleMenu(this)">
    Student Management <span class="arrow">▾</span>
  </div>
  <div class="submenu">
    <div onclick="openSection('add-student')">Add Student</div>
    <div onclick="openSection('student-list')">Student List</div>
    <div onclick="openSection('academic-history')">Academic History</div>
    <div onclick="openSection('promote-student')">Promote Student</div>
  </div>

  <div class="menu-item" onclick="toggleMenu(this)">
    Enrollment <span class="arrow">▾</span>
  </div>
  <div class="submenu">
    <div onclick="openSection('new-enrollment')">New Enrollment</div>
    <div onclick="openSection('re-enrollment')">Re-Enrollment</div>
    <div onclick="openSection('enrollment-approval')">Enrollment Approval</div>
    <div onclick="openSection('enrollment-status')">Enrollment Status</div>
  </div>

  <div class="menu-item" onclick="openSection('reports')">Reports</div>
  <div class="menu-item" onclick="openSection('settings')">Settings</div>
  
  <hr style="opacity: 0.1; margin: 10px 0;">
  
  <div class="menu-item" onclick="confirmLogout()" style="color: #fb7185;">
    <strong>Logout</strong>
  </div>

</div>

  <!-- Main -->
  <div class="main">

    <!-- Topbar -->
    <div class="topbar">
      <div>
        <span class="toggle" onclick="toggleSidebar()"></span>
      </div>
      <div>
        Role:
        <select class="role-select" onchange="changeRole(this.value)">
          <option value="Admin">Admin</option>
          <option value="Registrar">Registrar</option>
          <option value="Teacher">Teacher</option>
        </select>
      </div>
    </div>

    <div class="content">

      <!-- Search -->
      <div class="card">
        <h3>Search Student</h3>
        <div class="search-bar">
          <input type="text" placeholder="Enter student name or ID">
          <button class="btn-primary">Search</button>
        </div>
      </div>

      <!-- Student Info -->
      <div class="card">
        <h3>Student Information</h3>
        <div class="form-grid">
          <div>
            <label>First Name</label>
            <input type="text">
          </div>
          <div>
            <label>Last Name</label>
            <input type="text">
          </div>
          <div>
            <label>Grade Level</label>
            <select></select>
          </div>
          <div>
            <label>Date of Birth</label>
            <input type="date">
          </div>
          <div>
            <label>Student ID</label>
            <input type="text">
          </div>
          <div>
            <label>Section</label>
            <select></select>
          </div>
        </div>
      </div>

      <!-- Enrollment Section -->
      <div class="row">

        <div class="card">
          <h3>Enrollment Details</h3>

          <label>Subject Code</label>
          <select></select>

          <br><br>

          <label>Subject Title</label>
          <select></select>

          <br><br>

          <label>Available Slots</label>
          <input type="number" value="5">

          <div class="confirm-box">
            Slots Available. Ready to Confirm Enrollment.
          </div>
        </div>

        <div class="card">
          <h3>Enrollment Slip / Proof</h3>

          <p><strong>Name:</strong> </p>
          <p><strong>Student ID:</strong> </p>
          <p><strong>Section:</strong> </p>
          <p><strong>Subject:</strong> </p>

          <br>
          <button class="btn-dark">Print Enrollment Slip</button>
        </div>

      </div>

      <!-- Bottom Actions -->
      <div class="card">
        <div class="actions">
          <button class="btn-secondary">Select Another Section</button>
          <button class="btn-primary">Confirm Enrollment</button>
          <button class="btn-success">Approve Enrollment</button>
          <button class="btn-dark">Finish Enrollment</button>
        </div>
      </div>

    </div>
  </div>
</div>

<script>

  function openSection(section) {
  // You can replace these alerts with: window.location.href = section + ".php";
  switch(section) {
    case 'dashboard':
      console.log("Loading Dashboard...");
      break;
    case 'add-admin':
    case 'add-teacher':
      alert("Opening User Creation Form...");
      break;
    case 'student-list':
    case 'students':
      alert("Loading Student Database...");
      break;
    case 'new-enrollment':
      alert("Starting New Enrollment Process...");
      break;
    case 'reports':
      alert("Generating System Reports...");
      break;
    case 'settings':
      alert("Opening System Settings...");
      break;
    case 'logout':
      confirmLogout();
      break;
    default:
      alert("Navigating to: " + section.replace('-', ' '));
  }
}

function confirmLogout() {
  if (confirm("Are you sure you want to logout?")) {
    alert("Logged out successfully.");
    // window.location.href = "login.php";
  }
}

// Keep your existing toggleMenu and toggleSidebar functions below 
    function openSection(section){

  switch(section){

    case 'students':
      alert("Opening Student List Page...");
      break;

    case 'enrolled':
      alert("Opening Enrollment Records...");
      break;

    case 'slots':
      alert("Opening Section Slot Management...");
      break;

    case 'sections':
      alert("Opening Section Management...");
      break;

    default:
      alert("Section not found");
  }

}

    // Sample Data (Mock Database)
    let totalStudents = 520;
    let totalEnrolled = 480;
    let totalSlots = 40;

    // Load Stats
    document.getElementById("totalStudents").innerText = totalStudents;
    document.getElementById("totalEnrolled").innerText = totalEnrolled;
    document.getElementById("totalSlots").innerText = totalSlots;

    // Sidebar Toggle
    function toggleSidebar(){
      document.getElementById("sidebar").classList.toggle("collapsed");
    }

    // Dropdown Toggle
    function toggleMenu(element){
      element.classList.toggle("active");
    }

    // Role-Based Menu
    function changeRole(role){
      const adminItems = document.querySelectorAll(".admin-only");

      if(role === "Admin"){
        adminItems.forEach(item => item.style.display="block");
      }else{
        adminItems.forEach(item => item.style.display="none");
      }
    }
</script>

</body>
</html>