<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anahaway National High School | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top shadow-sm">
    <div class="container">

        <!-- Logo + School Name -->
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWzjUEQ1sCA6A1bnpVoojVV7zNi7vdyYpXfA&s"
                 alt="ANHS Logo"
                 class="rounded-circle"
                 width="45"
                 height="45"
                 style="object-fit: cover;">
            <div class="d-flex flex-column">
                <span class="fw-bold fs-5">Anahaway National High School</span>
                <small class="text-warning" style="font-size: 12px;">Education turns potential into power</small>
            </div>
        </a>

        <!-- Mobile Toggle -->
        <button class="navbar-toggler border-0" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu -->
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="home.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="about.php">About</a>
                </li>


                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="programs.php">Programs</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="courses.php">Courses</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="admissions.php">Admissions</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="contact.php">Contact</a>
                </li>

                <li class="nav-item">
                    <a class="btn btn-warning px-4 fw-semibold ms-lg-3"
                       href="../views/dashboard.php"
                       style="border-radius: 30px;">
                        Admin
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>