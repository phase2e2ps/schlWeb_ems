<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Programs | ANHS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --primary-navy: #1a2a6c;
            --accent-orange: #ff4b2b;
            --dark-gray: #2d3436;
            --soft-white: #f9f9f9;
        }

        body { font-family: 'Poppins', sans-serif; background-color: #fff; color: var(--dark-gray); }

        /* Hero Banner with Modern Slant */
        .programs-hero {
            background: linear-gradient(135deg, rgba(26, 42, 108, 0.9), rgba(255, 75, 43, 0.8)), 
                        url('https://scontent.fceb6-1.fna.fbcdn.net/v/t39.30808-6/589937137_3228677750618337_2484065491335759303_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=dd6889&_nc_eui2=AeHKx360OF_IrCFLB4snBX_f8xbSK_-Wu_3zFtIr_5a7_VhL_P7U8S4zFqOL8Sei0KW5BUrJX9k6Luia1ceiC2gC&_nc_ohc=0tHq9chZt7EQ7kNvwHi1Pe2&_nc_oc=AdkV3tR3OSN5mf68pYY3YHibV3yQlzCby6d8SQVwYqc1IxvCR0ElYHvKkdzlWdUdV2E&_nc_zt=23&_nc_ht=scontent.fceb6-1.fna&_nc_gid=Jqv8JILHzC2r154eeTwcfA&oh=00_AftN1OkWSsNXbSB5cqjv7Qu0g2pfS-6DtBu3duMol26ZqA&oe=699C5C18');
            background-size: cover;
            background-position: center;
            padding: 100px 0;
            color: white;
            clip-path: polygon(0 0, 100% 0, 100% 90%, 0% 100%);
        }

        /* Mission & Vision Cards */
        .mv-card {
            border: none;
            border-top: 5px solid var(--accent-orange);
            background: var(--soft-white);
            transition: 0.3s;
            height: 100%;
        }
        .mv-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.05); }

        /* Program Offerings */
        .program-card {
            border-radius: 15px;
            overflow: hidden;
            border: 1px solid #eee;
            transition: 0.4s;
        }
        .program-card:hover { border-color: var(--accent-orange); }
        .program-img { height: 200px; background: #dfe6e9; overflow: hidden; }
        .program-img img { width: 100%; height: 100%; object-fit: cover; }
        .btn-view { background: var(--dark-gray); color: white; border-radius: 0; padding: 10px; width: 100%; }
        .btn-view:hover { background: var(--accent-orange); color: white; }

        /* Feature Icons */
        .feature-box {
            padding: 30px;
            text-align: center;
            border: 1px solid #eee;
            border-radius: 10px;
            transition: 0.3s;
        }
        .feature-box:hover { background: var(--primary-navy); color: white; }
        .feature-box i { font-size: 2.5rem; margin-bottom: 15px; color: var(--accent-orange); }
        .feature-box:hover i { color: #fff; }

        /* Enrollment CTA */
        .enroll-footer {
            background: #eee;
            padding: 60px 0;
            text-align: center;
            margin-top: 50px;
        }
        .btn-enroll-final {
            background: linear-gradient(to right, #ff4b2b, #ff416c);
            color: white;
            padding: 15px 50px;
            font-size: 1.5rem;
            font-weight: 800;
            text-transform: uppercase;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
        }
        .btn-enroll-final:hover { transform: scale(1.1); box-shadow: 0 10px 20px rgba(255, 75, 43, 0.3); color: white; }
    </style>
</head>
<body>

<?php include 'nav/header.php'; ?>

<section class="programs-hero text-center">
    <div class="container">
        <h1 class="display-3 fw-bolder" style="font-family: 'Montserrat';">OUR PROGRAMS</h1>
        <p class="lead opacity-75">Developing global leaders through a diverse and rigorous curriculum.</p>
    </div>
</section>

<main class="container py-5">
    
    <div class="row g-4 mb-5 text-center">
        <div class="col-md-6">
            <div class="card mv-card p-4">
                <h2 class="fw-bold mb-3">Our Mission</h2>
                <p class="text-muted">To empower every student with knowledge, values, and skills to thrive in a rapidly changing world through academic excellence and innovation.</p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mv-card p-4">
                <h2 class="fw-bold mb-3">Our Vision</h2>
                <p class="text-muted">A premier institution recognized for producing compassionate, competent leaders who contribute meaningfully to national progress.</p>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-5 mt-5">
        <?php 
        $strands = [
            ['title' => 'STEM', 'desc' => 'Science, Technology, Engineering, and Mathematics focus.', 'img' => 'https://scontent.fceb6-4.fna.fbcdn.net/v/t39.30808-6/590238778_3226027297550049_6400893977390055508_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeFjU6pa24a0kHg5xNIYDFEkvogGIMLdC0O-iAYgwt0LQ23PY2AwvmtXoWUsxzAGojwtImw9PlHuY--HmBS2SkQe&_nc_ohc=XXJQ0EIyFNgQ7kNvwHNTMWE&_nc_oc=Adnd2UtBmhqGpOBILSPGrpBG0Ha9f5ANmrVDcUcSjuV9LFFerCT6ko8Z3lpRIFAt-R4&_nc_zt=23&_nc_ht=scontent.fceb6-4.fna&_nc_gid=BEa77NRtx94IYb6ikH3k9A&oh=00_AftMBd65DEF1njay1sE-c8CqRWOz5kclhu8giSV-zpFr2A&oe=699C4FE0'],
            ['title' => 'ABM', 'desc' => 'Accountancy, Business, and Management leadership.', 'img' => 'https://scontent.fceb6-4.fna.fbcdn.net/v/t39.30808-6/590238778_3226027297550049_6400893977390055508_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeFjU6pa24a0kHg5xNIYDFEkvogGIMLdC0O-iAYgwt0LQ23PY2AwvmtXoWUsxzAGojwtImw9PlHuY--HmBS2SkQe&_nc_ohc=XXJQ0EIyFNgQ7kNvwHNTMWE&_nc_oc=Adnd2UtBmhqGpOBILSPGrpBG0Ha9f5ANmrVDcUcSjuV9LFFerCT6ko8Z3lpRIFAt-R4&_nc_zt=23&_nc_ht=scontent.fceb6-4.fna&_nc_gid=BEa77NRtx94IYb6ikH3k9A&oh=00_AftMBd65DEF1njay1sE-c8CqRWOz5kclhu8giSV-zpFr2A&oe=699C4FE0'],
            ['title' => 'HUMSS', 'desc' => 'Humanities and Social Sciences for future change-makers.', 'img' => 'https://scontent.fceb6-4.fna.fbcdn.net/v/t39.30808-6/590238778_3226027297550049_6400893977390055508_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeFjU6pa24a0kHg5xNIYDFEkvogGIMLdC0O-iAYgwt0LQ23PY2AwvmtXoWUsxzAGojwtImw9PlHuY--HmBS2SkQe&_nc_ohc=XXJQ0EIyFNgQ7kNvwHNTMWE&_nc_oc=Adnd2UtBmhqGpOBILSPGrpBG0Ha9f5ANmrVDcUcSjuV9LFFerCT6ko8Z3lpRIFAt-R4&_nc_zt=23&_nc_ht=scontent.fceb6-4.fna&_nc_gid=BEa77NRtx94IYb6ikH3k9A&oh=00_AftMBd65DEF1njay1sE-c8CqRWOz5kclhu8giSV-zpFr2A&oe=699C4FE0']
        ];
        foreach($strands as $s): ?>
        <div class="col-lg-4">
            <div class="program-card">
                <div class="program-img">
                    <img src="<?php echo $s['img']; ?>" alt="Program">
                </div>
                <div class="p-4 text-center">
                    <h5 class="fw-bold">Senior High School</h5>
                    <p class="small text-muted mb-4"><?php echo $s['desc']; ?></p>
                    <button class="btn btn-view">View Programs</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="text-center mt-5 mb-5">
        <h2 class="fw-bold display-6">Why Study With Us?</h2>
        <p class="text-muted">We provide an environment designed for holistic student success.</p>
    </div>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="feature-box">
                <i class="fas fa-chalkboard-teacher"></i>
                <h6 class="fw-bold">Experienced Faculty</h6>
                <p class="small opacity-75">Expert educators dedicated to student growth.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="feature-box">
                <i class="fas fa-chart-line"></i>
                <h6 class="fw-bold">Career Opportunity</h6>
                <p class="small opacity-75">Strong pathways to top-tier universities and industry.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="feature-box">
                <i class="fas fa-microscope"></i>
                <h6 class="fw-bold">Modern Facilities</h6>
                <p class="small opacity-75">State-of-the-art laboratories and research centers.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="feature-box">
                <i class="fas fa-book-reader"></i>
                <h6 class="fw-bold">Rich Resources</h6>
                <p class="small opacity-75">Comprehensive libraries and digital learning tools.</p>
            </div>
        </div>
    </div>

</main>

<footer class="enroll-footer">
    <div class="container">
        <h2 class="display-5 fw-bold mb-2">Start Your Future Today</h2>
        <p class="text-muted mb-4">Take the next step toward your academic success.</p>
        <a href="admission.php" class="btn-enroll-final">Enroll Now</a>
    </div>
</footer>

<?php include 'nav/footer.php'; ?>

</body>
</html>