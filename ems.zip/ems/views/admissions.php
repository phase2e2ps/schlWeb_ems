<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission | Anahaway National High School</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --primary-navy: #1a2a6c;
            --accent-orange: #ff4b2b;
            --gold-gradient: linear-gradient(45deg, #f2994a, #f2c94c);
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body { font-family: 'Poppins', sans-serif; background-color: #fcfcfc; }

        /* Catchy Hero Section */
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), 
                        url('https://scontent.fceb6-1.fna.fbcdn.net/v/t39.30808-6/623808579_3293207517498693_320058447635427522_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeG1aV6WmIR9pzJP-nr7PUknNdv6NtN8ohI12_o203yiEjOoU-7w1HwboU0MTQvWaDZq8LQWrbtW4gg4EXOUmgbW&_nc_ohc=ycNT-8sHXtsQ7kNvwHBkGc4&_nc_oc=AdlrzTmUu6joB8hhLduGAGH_QL_ac3N_akTsurEXqybNV2wVRQzcnT2VuWLlV5QBfyc&_nc_zt=23&_nc_ht=scontent.fceb6-1.fna&_nc_gid=0r-MNIS2JybMxC8pFOOIhw&oh=00_Afs7vSY421ErSILNN22rEcy6vycA6_Uepn-KP6qcEIxy1A&oe=699C5DFA');
            background-size: cover;
            background-attachment: fixed;
            padding: 120px 0;
            border-bottom: 8px solid var(--accent-orange);
        }

        .enroll-now-text {
            font-family: 'Montserrat', sans-serif;
            font-size: 5rem;
            font-weight: 900;
            text-transform: uppercase;
            background: var(--gold-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            filter: drop-shadow(0 10px 15px rgba(0,0,0,0.3));
            transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .enroll-now-text:hover { transform: scale(1.1) rotate(-2deg); }

        /* Admission Cards */
        .admission-card {
            border: none;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0,0,0,0.05);
            transition: 0.3s;
            background: #fff;
        }

        .admission-card:hover { transform: translateY(-15px); box-shadow: 0 20px 40px rgba(0,0,0,0.12); }

        .card-img-holder {
            height: 220px;
            background: #eee;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .card-img-holder img { width: 100%; height: 100%; object-fit: cover; transition: 0.5s; }
        .admission-card:hover .card-img-holder img { transform: scale(1.1); }

        .btn-explore {
            border: 2px solid var(--accent-orange);
            color: var(--accent-orange);
            font-weight: 700;
            border-radius: 30px;
            padding: 10px 25px;
            transition: 0.3s;
        }

        .btn-explore:hover { background: var(--accent-orange); color: #fff; }

        /* Requirement Steps */
        .requirement-list li {
            padding: 15px;
            border-radius: 12px;
            background: #fff;
            margin-bottom: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
            border-left: 5px solid #ddd;
            transition: 0.3s;
        }

        .requirement-list li:hover { border-left-color: var(--accent-orange); transform: translateX(10px); }

        /* Download Box */
        .download-box {
            background: var(--primary-navy);
            color: white;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .download-box::before {
            content: "\f1c1";
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            position: absolute;
            font-size: 10rem;
            color: rgba(255,255,255,0.05);
            bottom: -30px;
            right: -20px;
        }
    </style>
</head>
<?php include 'nav/header.php'; ?>

<body>
<section class="hero-section text-white text-center">
    <div class="container">
        <h1 class="display-5 fw-bold mb-3">Shape Your Future At ANHS</h1>
        <p class="lead mb-5 col-lg-7 mx-auto opacity-75">Your journey toward excellence starts with a single click. Join our vibrant academic community today.</p>
        <a href="#" class="enroll-now-text d-block">Enroll Now</a>
    </div>
</section>

<main class="container py-5">
    <div class="text-center mb-5">
        <h2 class="fw-extrabold display-6" style="font-family: 'Montserrat';">ADMISSION <span style="color:var(--accent-orange)">CATEGORIES</span></h2>
        <div class="mx-auto" style="width: 80px; height: 5px; background: var(--accent-orange); border-radius: 5px;"></div>
    </div>

    <div class="row g-4 mb-5">
        <?php 
        $types = [
            ['title' => 'Undergraduate', 'desc' => 'Start your journey with our diverse SHS strands.', 'img' => 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=500'],
            ['title' => 'Graduate', 'desc' => 'Advance your career with our specialized programs.', 'img' => 'https://images.unsplash.com/photo-1541339907198-e08756ebafe1?q=80&w=500'],
            ['title' => 'Scholarships', 'desc' => 'Financial support for deserving high-achievers.', 'img' => 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=500']
        ];
        foreach($types as $type): ?>
        <div class="col-lg-4">
            <div class="admission-card p-0">
                <div class="card-img-holder">
                    <img src="<?php echo $type['img']; ?>" alt="Admission">
                </div>
                <div class="p-4 text-center">
                    <h3 class="fw-bold h4"><?php echo $type['title']; ?></h3>
                    <p class="text-muted small mb-4"><?php echo $type['desc']; ?></p>
                    <button class="btn btn-explore w-100">View Details</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="row py-5 g-5">
        <div class="col-lg-7">
            <div class="d-flex align-items-center mb-4">
                <i class="fas fa-clipboard-list fa-2x me-3 text-danger"></i>
                <h2 class="fw-bold m-0">Admission Checklist</h2>
            </div>
            <ul class="list-unstyled requirement-list">
                <li><i class="fas fa-file-alt text-danger me-3"></i> Duly accomplished Application Form</li>
                <li><i class="fas fa-id-card text-danger me-3"></i> Authenticated Grade 12 Report Card</li>
                <li><i class="fas fa-fingerprint text-danger me-3"></i> Learner's Reference Number (LRN)</li>
                <li><i class="fas fa-history text-danger me-3"></i> Transcript of Records (For Transferees)</li>
                <li><i class="fas fa-heart text-danger me-3"></i> Certificate of Good Moral Character</li>
                <li><i class="fas fa-baby text-danger me-3"></i> PSA Certified Birth Certificate</li>
            </ul>
        </div>
        
        <div class="col-lg-5">
            <div class="download-box shadow-lg">
                <i class="fas fa-file-pdf fa-4xl mb-4 text-warning"></i>
                <h3 class="fw-bold mb-3">Ready to Apply?</h3>
                <p class="opacity-75 mb-4">Download the official enrollment form and start your application today.</p>
                <a href="#" class="btn btn-warning fw-bold px-5 py-3 rounded-pill text-dark shadow">
                    <i class="fas fa-download me-2"></i> DOWNLOAD FORM
                </a>
                <p class="mt-4 small opacity-50">File Format: PDF (Portable Document Format)</p>
            </div>
        </div>
    </div>
</main>

<?php include 'nav/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>