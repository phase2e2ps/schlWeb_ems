<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anahaway National High School | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
</head>
 <?php
    include 'nav/header.php';
 ?>
<body>
<!-- HERO SECTION -->
<section class="hero-section d-flex align-items-center text-white text-center">
    <div class="container position-relative">

        <h1 class="display-4 fw-bold mb-3">
            Welcome to Anahaway National High School
        </h1>

        <p class="lead mb-4 col-lg-8 mx-auto">
            Empowering students through quality education, innovation,
            leadership, and a modern Enrollment Management System.
        </p>

        <div class="d-flex justify-content-center flex-wrap">
    <a href="#" class="enroll-now-text">
        Enroll Now
    </a>
</div>

<style>
    .enroll-now-text {
        font-size: 4rem; /* Adjust size as needed */
        font-weight: 900;
        text-transform: uppercase;
        text-decoration: none;
        letter-spacing: -2px;
        
        /* Gradient Text Effect */
        background: linear-gradient(to bottom, #ffc107, #ff8c00);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        
        /* The "Photo Integration" look */
        /* This shadow makes the text look like it's cut out or sitting on the image */
        filter: drop-shadow(2px 4px 6px rgba(0,0,0,0.3));
        
        transition: transform 0.3s ease, filter 0.3s ease;
        display: inline-block;
    }

    .enroll-now-text:hover {
        transform: scale(1.05);
        filter: drop-shadow(4px 8px 12px rgba(0,0,0,0.5));
        -webkit-text-fill-color: #ffc107; /* Fallback/Solid color on hover if desired */
    }
</style>

    </div>
</section>


<!-- FEATURES -->
<section class="py-5">
    <div class="container text-center">
        <h2 class="section-title mb-5">What We Offer</h2>
        <div class="row g-4">

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-user-graduate fa-3x text-primary mb-3"></i>
                    <h5>Certified Teachers</h5>
                    <p>Highly qualified educators committed to excellence.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-book-open fa-3x text-primary mb-3"></i>
                    <h5>Modern Curriculum</h5>
                    <p>Industry-aligned programs designed for success.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-building-columns fa-3x text-primary mb-3"></i>
                    <h5>Advanced Facilities</h5>
                    <p>Smart classrooms and modern learning tools.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-futbol fa-3x text-primary mb-3"></i>
                    <h5>Sports & Clubs</h5>
                    <p>Holistic development through extracurricular activities.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ABOUT SECTION -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">About Our School</h2>
                <p>
                    Anahaway National High School is dedicated to providing quality
                    education and shaping future leaders through innovation and
                    excellence.
                </p>
                <a href="#" class="btn btn-primary">Learn More</a>
            </div>
            <div class="col-md-6 text-center">
                <img src="https://scontent.fceb6-3.fna.fbcdn.net/v/t39.30808-6/586638370_3225991110887001_1062165880233093428_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=dd6889&_nc_eui2=AeGc6umHAQA5SVdEoUM0PBWKAkicL-aeqqwCSJwv5p6qrEVpqbZ1mjAkkXHP34m-3AjjpP7FtHBIxamwINydld-l&_nc_ohc=_xst0NNVNRgQ7kNvwF-dbsI&_nc_oc=AdlR2DiIUPW2pkqekppK0dHudGwusl40XMBL55VlgK31oEGiANNmliHbpUXYE9V52GY&_nc_zt=23&_nc_ht=scontent.fceb6-3.fna&_nc_gid=YRKXvtdIVDDYwJ2-wffSag&oh=00_AfvhEhtklnx2q7MvBbhbREPD3kuBrcMPBjho-Yl3yCoI7Q&oe=699C3B3E"
                     class="img-fluid rounded shadow" alt="School">
            </div>
        </div>
    </div>
</section>

<!-- CTA SECTION -->
<section class="py-5 text-center">
    <div class="container">
        <h2 class="section-title">Ready to Enroll?</h2>
        <p class="lead">Start your journey with us today.</p>
        <a href="#" class="btn btn-primary btn-lg">Apply for Admission</a>
    </div>
</section>

<!-- SCHOOL OVERVIEW -->
<section class="py-5 bg-light border-top">
    <div class="container">
        <div class="row align-items-center mb-5">

            <!-- Image -->
            <div class="col-md-4 mb-4 mb-md-0">
                <img src="https://scontent.fceb6-3.fna.fbcdn.net/v/t39.30808-6/536267980_3126241167528663_179359250517254412_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=101&ccb=1-7&_nc_sid=2a1932&_nc_eui2=AeGJCCNveiFlM0-pQUMnr3a287Yz9X-CUx_ztjP1f4JTH8INhNVVfdQLlRyk-VxaoFDF0Hnyss9F8vhVRqiuYHk0&_nc_ohc=gnNkDKm5hJEQ7kNvwF7Ytu9&_nc_oc=AdmoNLVLeCzVLkv-82kc51lRTlviEl2r4E1yvGDrpS0u7VVjFxthIwTJXy8XegW5e1w&_nc_zt=23&_nc_ht=scontent.fceb6-3.fna&_nc_gid=Q16qIhu7K5P8_5OiFhhIDQ&oh=00_AfsLplmibupnPRaxLIl4e4WigcHHZ9DIT3RKJvlzbGm2SQ&oe=699C4921"
                     class="img-fluid rounded shadow-sm"
                     alt="School Image">
            </div>

            <!-- Description -->
            <div class="col-md-8">
                <h3 class="fw-bold">Anahaway National High School</h3>
                <p class="text-muted">
                    Anahaway National High School provides quality secondary education
                    focused on academic excellence, leadership development, and
                    holistic student growth.
                </p>

                <!-- Stats -->
                <div class="row text-center mt-4 g-3">

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">18</h2>
                            <small class="text-muted">Certified Teachers</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">43</h2>
                            <small class="text-muted">Students</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">10</h2>
                            <small class="text-muted">Courses</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">50</h2>
                            <small class="text-muted">Awards Won</small>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- COURSES -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Courses</h2>
            <p class="text-muted">
                Explore our academic programs designed to equip students with
                knowledge, skills, and leadership excellence.
            </p>
        </div>

        <div class="row g-4">

            <!-- Course Card -->
            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card h-100 shadow-sm border-0 course-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/508010346_3046408782178569_2948208103578868285_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeHsbOlo_f3rJ43c95ZsGm3xZr9pca3hGw1mv2lxreEbDZZshCwpPJGBr_y_13TSP04xWnp3xhtmRJVNCPkf2nW2&_nc_ohc=94fRORS71wUQ7kNvwEGurUm&_nc_oc=AdlbZuup6OZeAs5rBuzMMAnaYX9jUCNcQ1_6ziWXsY12WHRy2dmsHKMtprIsoprHYPI&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=f3UTH0dQ0UEX_3Sps7E7Xw&oh=00_AftAmQllmZAvOJpkjfSGGvg9Pt9b7dntm3KNGgoJT_1llQ&oe=699C533C"
                         class="card-img-top"
                         style="height:180px; object-fit:cover;"
                         alt="Course">

                    <div class="card-body text-center">
                        <h5 class="fw-bold">Course <?php echo $i; ?></h5>
                        <p class="text-muted small">
                            Comprehensive curriculum designed to build
                            strong academic foundations.
                        </p>
                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Apply Now
                        </a>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- CERTIFIED TEACHERS -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Certified Teachers</h2>
            <p class="text-muted">
                Our faculty members are highly trained professionals
                committed to delivering quality education.
            </p>
        </div>

        <div class="row g-4">

            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card text-center shadow-sm border-0 teacher-card">
                    <img src="https://scontent.fceb6-3.fna.fbcdn.net/v/t39.30808-6/536267980_3126241167528663_179359250517254412_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=101&ccb=1-7&_nc_sid=2a1932&_nc_eui2=AeGJCCNveiFlM0-pQUMnr3a287Yz9X-CUx_ztjP1f4JTH8INhNVVfdQLlRyk-VxaoFDF0Hnyss9F8vhVRqiuYHk0&_nc_ohc=gnNkDKm5hJEQ7kNvwF7Ytu9&_nc_oc=AdmoNLVLeCzVLkv-82kc51lRTlviEl2r4E1yvGDrpS0u7VVjFxthIwTJXy8XegW5e1w&_nc_zt=23&_nc_ht=scontent.fceb6-3.fna&_nc_gid=Q16qIhu7K5P8_5OiFhhIDQ&oh=00_AfsLplmibupnPRaxLIl4e4WigcHHZ9DIT3RKJvlzbGm2SQ&oe=699C4921<?php echo rand(10,99); ?>.jpg"
                         class="rounded-circle mx-auto mt-4"
                         width="100"
                         height="100"
                         style="object-fit:cover;"
                         alt="Teacher">

                    <div class="card-body">
                        <h6 class="fw-bold mb-1">Teacher Name</h6>
                        <small class="text-muted">Subject Specialist</small>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- TEACHERS + REQUEST QUOTE SECTION -->
<section class="py-5 border-top">
    <div class="container">

        <!-- Section Title -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Other Certified Teachers</h2>
            <p class="text-muted">
                Meet our professional educators dedicated to student success.
            </p>
        </div>

        <!-- Teachers Row -->
        <div class="row g-4 mb-5">

            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card shadow-sm border-0 text-center h-100">
                    <img src="https://scontent.fceb6-3.fna.fbcdn.net/v/t39.30808-6/536267980_3126241167528663_179359250517254412_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=101&ccb=1-7&_nc_sid=2a1932&_nc_eui2=AeGJCCNveiFlM0-pQUMnr3a287Yz9X-CUx_ztjP1f4JTH8INhNVVfdQLlRyk-VxaoFDF0Hnyss9F8vhVRqiuYHk0&_nc_ohc=gnNkDKm5hJEQ7kNvwF7Ytu9&_nc_oc=AdmoNLVLeCzVLkv-82kc51lRTlviEl2r4E1yvGDrpS0u7VVjFxthIwTJXy8XegW5e1w&_nc_zt=23&_nc_ht=scontent.fceb6-3.fna&_nc_gid=Q16qIhu7K5P8_5OiFhhIDQ&oh=00_AfsLplmibupnPRaxLIl4e4WigcHHZ9DIT3RKJvlzbGm2SQ&oe=699C4921<?php echo rand(10,99); ?>.jpg"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Teacher">

                    <div class="card-body">
                        <h6 class="fw-bold mb-1">Teacher Name <?php echo $i; ?></h6>
                        <small class="text-muted d-block mb-2">Subject Specialist</small>
                        <p class="small text-muted">
                            Dedicated educator with experience in modern teaching strategies.
                        </p>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>

        <!-- Request Quote Section -->
        <div class="row align-items-center bg-light p-4 rounded shadow-sm">

            <!-- Image -->
            <div class="col-md-6 mb-4 mb-md-0">
                <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                     class="img-fluid rounded"
                     alt="School">
            </div>

            <!-- Form -->
            <div class="col-md-6">
                <h3 class="fw-bold mb-3">Request Information</h3>
                <p class="text-muted small">
                    Fill out the form below and we will get back to you shortly.
                </p>

                <form>
                    <div class="row g-3">

                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="First Name">
                        </div>

                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Last Name">
                        </div>

                        <div class="col-12">
                            <select class="form-select">
                                <option selected>Select Course</option>
                                <option>Science</option>
                                <option>Mathematics</option>
                                <option>English</option>
                                <option>Technology</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <input type="email" class="form-control" placeholder="Email Address">
                        </div>

                        <div class="col-12">
                            <button class="btn btn-warning w-100 fw-semibold">
                                Request Information
                            </button>
                        </div>

                    </div>
                </form>

            </div>

        </div>

    </div>
</section>

<!-- UPCOMING EVENTS -->
<section class="py-5 bg-light border-top">
    <div class="container">

        <!-- Section Header -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Upcoming <span class="text-primary">Events</span></h2>
            <p class="text-muted">
                Stay connected with campus life. Join our upcoming events, workshops, and activities.
            </p>
        </div>

        <!-- Events Row -->
        <div class="row g-4">

            <!-- Event 1 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">15</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">10:00 AM - 4:00 PM</small>
                                <h6 class="fw-bold mt-1">Spring Open House</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Join us for a campus tour and discover our academic programs and facilities.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

            <!-- Event 2 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">22</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">2:00 PM - 5:00 PM</small>
                                <h6 class="fw-bold mt-1">Research Symposium</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Students showcase innovative research projects and academic achievements.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

            <!-- Event 3 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">28</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">6:00 PM - 9:00 PM</small>
                                <h6 class="fw-bold mt-1">Alumni Networking Night</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Connect with alumni and expand professional opportunities.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

        </div>

        <!-- View All Button -->
        <div class="text-center mt-5">
            <a href="#" class="btn btn-primary px-4 fw-semibold">
                View All Events
            </a>
        </div>

    </div>
</section>

<!-- RECENT BLOG -->
<section class="py-5 border-top">
    <div class="container">

        <!-- Section Header -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Recent <span class="text-dark">Blog</span></h2>
            <p class="text-muted">
                Stay updated with our latest news, articles, and school updates.
            </p>
        </div>

        <div class="row g-4">

            <?php for($i=1; $i<=3; $i++): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 blog-card">

                    <!-- Blog Image -->
                    <div class="position-relative">
                        <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                             class="card-img-top"
                             style="height:220px; object-fit:cover;"
                             alt="Blog Image">

                        <!-- Date Badge -->
                        <div class="position-absolute top-0 start-0 bg-warning text-white text-center p-2"
                             style="width:70px;">
                            <h6 class="mb-0 fw-bold">26</h6>
                            <small>Feb</small><br>
                            <small>2026</small>
                        </div>
                    </div>

                    <!-- Blog Content -->
                    <div class="card-body text-center">
                        <h6 class="fw-bold">Skills To Develop Your Child Memory</h6>
                        <p class="text-muted small">
                            Discover practical techniques and school-supported activities
                            that help improve memory retention and learning skills.
                        </p>

                        <a href="#" class="btn btn-warning px-4 fw-semibold">
                            Learn More...
                        </a>
                    </div>

                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- TESTIMONIAL SECTION -->
<section class="testimonial-section py-5">
    <div class="container">

        <!-- Header -->
        <div class="text-center mb-4">
            <h2 class="fw-bold">What Our Students & Parents Say</h2>
            <p class="text-muted col-lg-8 mx-auto">
                We value the voices of our students and parents.
                Their experiences reflect our commitment to academic excellence,
                discipline, and holistic development.
            </p>
        </div>

        <!-- Testimonials -->
        <div class="row g-4 justify-content-center">

            <!-- Student -->
            <div class="col-md-5">
                <div class="testimonial-card p-4 h-100">
                    <div class="quote-icon mb-3">“</div>

                    <p class="testimonial-text">
                        Anahaway National High School provides a supportive
                        learning environment where students are encouraged
                        to grow academically and personally. The teachers
                        are dedicated and approachable.
                    </p>

                    <div class="d-flex align-items-center mt-4">
                        <div class="testimonial-avatar me-3">
                            <i class="fa-solid fa-user text-white"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-semibold">Juan Dela Cruz</h6>
                            <small class="text-muted">Grade 12 Student</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Parent -->
            <div class="col-md-5">
                <div class="testimonial-card p-4 h-100">
                    <div class="quote-icon mb-3">“</div>

                    <p class="testimonial-text">
                        As a parent, I am confident in the quality of education
                        my child receives. The school maintains strong values,
                        discipline, and a structured enrollment system.
                    </p>

                    <div class="d-flex align-items-center mt-4">
                        <div class="testimonial-avatar me-3">
                            <i class="fa-solid fa-user text-white"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-semibold">Maria Santos</h6>
                            <small class="text-muted">Parent</small>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- SCHOOL HIGHLIGHTS -->
<section class="school-highlights py-5">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">School Highlights</h2>
            <p class="text-muted">
                Stay updated with the latest news, events, and announcements.
            </p>
        </div>

        <div class="row g-4">

            <!-- Highlight 1 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="img-fluid highlight-img"
                         alt="Students in classroom">

                    <div class="p-4">
                        <h6 class="fw-semibold">Enrollment Now Open</h6>
                        <p class="text-muted small">
                            Online enrollment for School Year 2026–2027
                            is now available through our EMS portal.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

            <!-- Highlight 2 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="img-fluid highlight-img"
                         alt="Award ceremony">

                    <div class="p-4">
                        <h6 class="fw-semibold">Academic Excellence Award</h6>
                        <p class="text-muted small">
                            Congratulations to our honor students for
                            achieving outstanding academic performance.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

            <!-- Highlight 3 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://scontent.fceb2-2.fna.fbcdn.net/v/t39.30808-6/518164323_3071111873041593_1340870797492273874_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=110&ccb=1-7&_nc_sid=7b2446&_nc_eui2=AeGL6NIP_Hj3SvriuyXwnuxdOHFg5x-k2ts4cWDnH6Ta2_INsWSa3JCS6M94BdKKh4RoZ_RUFsa7wmXXwiB3LTI1&_nc_ohc=xk19k7L2eOEQ7kNvwF5b7SG&_nc_oc=AdmKK0NVip2bD82ZeusWx9OzcHgrO4vQr8Y6Q5dRsKF2XdeUlWJB5E2LIr4P02Nxmq8&_nc_zt=23&_nc_ht=scontent.fceb2-2.fna&_nc_gid=OWeby3qAMW23GzjD8yr26w&oh=00_AfvXnoDLegn_WNsU9kK8u9xe2fJG_zo8NkXLjcXPdw_UNg&oe=699C39C3"
                         class="img-fluid highlight-img"
                         alt="School community activity">

                    <div class="p-4">
                        <h6 class="fw-semibold">Community Outreach Program</h6>
                        <p class="text-muted small">
                            Students participated in our annual outreach
                            program promoting leadership and service.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php 
    include 'nav/footer.php';
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
