<?php include 'nav/header.php'; ?>

<style>
:root{
    --primary:#0f172a;
    --accent:#ff4b2b;
    --blue:#2563eb;
    --light:#f8fafc;
    --border:#e5e7eb;
}

body{
    font-family:'Inter',sans-serif;
    background:var(--light);
    color:#1e293b;
}

/* ================= HERO ================= */
.course-hero{
    background:linear-gradient(120deg,#0f172a,#1e3a8a);
    padding:100px 0 80px;
    color:#fff;
    position:relative;
    overflow:hidden;
}
.course-hero h1{
    font-weight:800;
}
.course-hero p{
    opacity:.8;
}

/* ================= FILTER ================= */
.filter-bar{
    background:#fff;
    padding:25px;
    border-radius:20px;
    box-shadow:0 20px 40px rgba(0,0,0,0.05);
    margin-top:-40px;
    position:relative;
    z-index:2;
}

/* ================= FEATURED CARDS ================= */
.course-card{
    background:#fff;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.05);
    transition:.4s;
    position:relative;
}
.course-card:hover{
    transform:translateY(-10px);
    box-shadow:0 20px 50px rgba(0,0,0,0.1);
}
.course-img{
    height:180px;
    background:linear-gradient(120deg,#dbeafe,#f1f5f9);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:2rem;
    color:#64748b;
}
.course-card .badge{
    position:absolute;
    top:15px;
    left:15px;
}
.course-card .btn{
    border-radius:50px;
}

/* ================= PROGRAM LIST ================= */
.program-row{
    background:#fff;
    border-radius:15px;
    padding:20px;
    margin-bottom:15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    transition:.3s;
    border:1px solid var(--border);
}
.program-row:hover{
    transform:translateX(6px);
    box-shadow:0 10px 25px rgba(0,0,0,0.05);
}
.program-icon{
    width:55px;
    height:55px;
    border-radius:12px;
    background:#f1f5f9;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:1.2rem;
}

/* ================= SIDEBAR ================= */
.sidebar-module{
    background:#fff;
    padding:25px;
    border-radius:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.05);
    margin-bottom:25px;
}
.quick-links-list{
    list-style:none;
    padding:0;
}
.quick-links-list li{
    margin-bottom:10px;
}
.quick-links-list a{
    text-decoration:none;
    color:#334155;
    font-weight:500;
}
.quick-links-list a:hover{
    color:var(--accent);
}

/* Sticky Sidebar */
@media(min-width:992px){
    .sticky-sidebar{
        position:sticky;
        top:100px;
    }
}
</style>


<!-- ================= HERO ================= -->
<section class="course-hero text-center">
    <div class="container">
        <h1 class="display-4 fw-bold">Explore Our Academic Programs</h1>
        <p class="lead mt-3">Choose your path. Build your future at ANHS.</p>
    </div>
</section>


<main class="container mb-5">

    <!-- FILTER -->
    <div class="filter-bar">
        <form class="row g-3 align-items-center">
            <div class="col-md-3">
                <select class="form-select">
                    <option selected>Program Type</option>
                    <option>Senior High School</option>
                    <option>Technical-Vocational</option>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select">
                    <option selected>Department</option>
                    <option>Academic</option>
                    <option>TVL</option>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" class="form-control" placeholder="Search programs...">
            </div>
            <div class="col-md-2">
                <button class="btn btn-dark w-100 rounded-pill">Search</button>
            </div>
        </form>
    </div>


    <div class="row mt-5 g-5">

        <!-- LEFT CONTENT -->
        <div class="col-lg-8">

            <h4 class="fw-bold mb-4">Featured Strands</h4>
            <div class="row g-4 mb-5">

                <?php
                $featured = [
                    ['title'=>'STEM Strand','desc'=>'Science, Technology, Engineering & Math focus.','icon'=>'fa-microscope'],
                    ['title'=>'ABM Strand','desc'=>'Accountancy, Business & Management leadership.','icon'=>'fa-chart-line'],
                    ['title'=>'HUMSS Strand','desc'=>'Humanities & Social Sciences pathway.','icon'=>'fa-users']
                ];
                foreach($featured as $f): ?>

                <div class="col-md-4">
                    <div class="course-card h-100">
                        <span class="badge bg-warning text-dark">Featured</span>
                        <div class="course-img">
                            <i class="fas <?php echo $f['icon']; ?>"></i>
                        </div>
                        <div class="p-4">
                            <h6 class="fw-bold"><?php echo $f['title']; ?></h6>
                            <p class="text-muted small"><?php echo $f['desc']; ?></p>
                            <a href="#" class="btn btn-outline-dark btn-sm w-100">View Details</a>
                        </div>
                    </div>
                </div>

                <?php endforeach; ?>
            </div>


            <h4 class="fw-bold mb-4">All Programs</h4>

            <?php
            $programs = [
                ['title'=>'Information Technology','info'=>'Software basics & digital systems.','icon'=>'fa-laptop-code'],
                ['title'=>'Communication Arts','info'=>'Public speaking & writing mastery.','icon'=>'fa-microphone'],
                ['title'=>'Hospitality Management','info'=>'Tourism & culinary foundation.','icon'=>'fa-utensils']
            ];
            foreach($programs as $p): ?>

            <div class="program-row">
                <div class="d-flex align-items-center gap-3">
                    <div class="program-icon">
                        <i class="fas <?php echo $p['icon']; ?>"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-1"><?php echo $p['title']; ?></h6>
                        <small class="text-muted"><?php echo $p['info']; ?></small>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <a href="#" class="btn btn-light btn-sm">Details</a>
                    <a href="#" class="btn btn-dark btn-sm rounded-pill">Apply</a>
                </div>
            </div>

            <?php endforeach; ?>

        </div>


        <!-- SIDEBAR -->
        <div class="col-lg-4">
            <div class="sticky-sidebar">

                <div class="sidebar-module">
                    <h6 class="fw-bold mb-3">Quick Links</h6>
                    <ul class="quick-links-list">
                        <li><a href="admissions.php">Admission Info</a></li>
                        <li><a href="#">Scholarships</a></li>
                        <li><a href="#">Tuition & Fees</a></li>
                        <li><a href="contact.php">Contact Office</a></li>
                    </ul>
                </div>

                <div class="sidebar-module text-center">
                    <h6 class="fw-bold mb-3">Need Assistance?</h6>
                    <i class="fas fa-headset fa-3x mb-3 text-primary"></i>
                    <p class="small text-muted">Talk to our admissions team.</p>
                    <h5 class="fw-bold">+63 912 345 6789</h5>
                    <a href="contact.php" class="btn btn-dark w-100 mt-3 rounded-pill">
                        Contact Us
                    </a>
                </div>

            </div>
        </div>

    </div>

</main>

<?php include 'nav/footer.php'; ?>
