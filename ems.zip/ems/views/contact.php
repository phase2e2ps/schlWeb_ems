<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anahaway National High School | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
</head>
 <?php
    include 'nav/header.php';
 ?>

 <style>
        :root {
    --primary: #2c3e50;    /* Deep Navy */
    --accent: #ff5733;     /* The Action Orange from wireframe */
    --text: #334155;
    --light-bg: #f8fafc;
    --border: #e2e8f0;
    --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
    color: var(--text);
    background-color: #fff;
}

.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

/* Header & Nav */
.site-header { border-bottom: 1px solid var(--border); }
.top-bar { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; }
.brand { display: flex; align-items: center; gap: 15px; }
.logo-icon { font-size: 2.5rem; color: var(--primary); }
.brand h1 { font-family: 'Playfair Display', serif; font-size: 1.5rem; line-height: 1; }
.header-actions { display: flex; align-items: center; gap: 20px; }

.main-nav { background: #fff; padding: 10px 0; border-top: 1px solid var(--border); position: sticky; top: 0; z-index: 100; }
.nav-wrapper { display: flex; align-items: center; gap: 30px; }
.nav-links { display: flex; list-style: none; gap: 25px; flex-grow: 1; }
.nav-links a { text-decoration: none; color: var(--text); font-weight: 600; font-size: 0.95rem; transition: 0.3s; }
.nav-links a.active, .nav-links a:hover { color: var(--accent); }

/* Hero Section */
.contact-hero { 
    background: #edf2f7; 
    margin: 30px 0; 
    border-radius: 12px; 
    display: flex; 
    overflow: hidden; 
    min-height: 280px;
}
.hero-content { flex: 1; padding: 60px; display: flex; flex-direction: column; justify-content: center; }
.hero-badge { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: #718096; margin-bottom: 15px; }
.display-title { font-size: 3.5rem; font-family: 'Playfair Display', serif; line-height: 1; }
.text-accent { color: var(--accent); }
.hero-visual { flex: 1; position: relative; }
.hero-visual img { width: 100%; height: 100%; object-fit: cover; }

/* Contact Layout */
.contact-layout { display: grid; grid-template-columns: 380px 1fr; gap: 40px; margin-bottom: 60px; }

/* Sidebar & Form */
.card { background: var(--light-bg); border: 1px solid var(--border); padding: 30px; border-radius: 8px; }
.form-group { margin-bottom: 20px; }
.form-group label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 0.9rem; }
.form-group input, .form-group textarea { 
    width: 100%; padding: 12px; border: 1px solid var(--border); border-radius: 6px; font-family: inherit;
}
.btn { 
    padding: 12px 24px; border-radius: 6px; font-weight: 600; cursor: pointer; border: none; transition: 0.3s; 
    text-decoration: none; text-align: center;
}
.btn-primary { background: var(--primary); color: white; }
.btn-accent { background: var(--accent); color: white; }
.btn-dark { background: #1a202c; color: white; }
.btn-block { width: 100%; }
.btn:hover { opacity: 0.9; transform: translateY(-1px); }

/* Info Cards */
.info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px; }
.info-card { display: flex; align-items: flex-start; gap: 15px; padding: 20px; border: 1px solid var(--border); border-radius: 8px; }
.info-card i { font-size: 1.2rem; color: var(--accent); margin-top: 5px; }
.info-card h4 { font-size: 1rem; margin-bottom: 5px; }

/* Map */
.map-wrapper { height: 350px; border-radius: 8px; overflow: hidden; margin-bottom: 30px; border: 1px solid var(--border); }
.map-wrapper iframe { width: 100%; height: 100%; border: 0; }

/* Feedback */
.feedback-card { border: 2px dashed var(--border); padding: 25px; border-radius: 8px; }
.feedback-input { display: flex; flex-direction: column; gap: 15px; margin-top: 15px; }
.feedback-input textarea { width: 100%; padding: 12px; border: 1px solid var(--border); border-radius: 6px; height: 80px; }

/* Responsive */
@media (max-width: 992px) {
    .contact-layout { grid-template-columns: 1fr; }
    .hero-content { padding: 40px; }
    .display-title { font-size: 2.5rem; }
}

.enroll-link {
            font-size: 3rem;
            font-weight: 800;
            text-transform: uppercase;
            background: linear-gradient(to bottom, var(--school-gold), #ff8c00);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }

        .enroll-link:hover { transform: scale(1.05); -webkit-text-fill-color: var(--school-gold); }

        /* Contact Content Layout */
        .contact-section { margin-top: -50px; padding-bottom: 80px; }
        
        .contact-card {
            background: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .form-header { background: var(--school-navy); color: white; padding: 25px; }
        
        .info-item {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            padding: 20px;
            background: var(--soft-bg);
            border-radius: 8px;
            height: 100%;
            transition: 0.3s;
        }
        
        .info-item:hover { background: #e2e8f0; }
        .info-item i { color: var(--school-accent); font-size: 1.25rem; margin-top: 4px; }
        .info-item h6 { font-weight: 700; margin-bottom: 5px; color: var(--school-navy); }

        .map-container {
            height: 400px;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        .qr-card {
            background: #fff;
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        /* Form Polish */
        .form-control { padding: 12px; border-color: var(--border-color); }
        .form-control:focus { border-color: var(--school-accent); box-shadow: 0 0 0 0.25rem rgba(255, 87, 51, 0.1); }
        .btn-accent { background: var(--school-accent); color: white; border: none; padding: 12px 30px; font-weight: 600; }
        .btn-accent:hover { background: #e64a2a; color: white; }

 </style>
<body>
<!-- HERO SECTION -->
<section class="hero-section d-flex align-items-center text-white text-center">
    <div class="container position-relative">

        <h1 class="display-4 fw-bold mb-3">
            Welcome to Anahaway National High School
        </h1>

        <p class="lead mb-4 col-lg-8 mx-auto">
            Empowering students through quality education, innovation,
            leadership, and a modern Enrollment Management System.
        </p>

        <div class="d-flex justify-content-center flex-wrap">
    <a href="#" class="enroll-now-text">
        Enroll Now
    </a>
</div>

<style>
    .enroll-now-text {
        font-size: 4rem; /* Adjust size as needed */
        font-weight: 900;
        text-transform: uppercase;
        text-decoration: none;
        letter-spacing: -2px;
        
        /* Gradient Text Effect */
        background: linear-gradient(to bottom, #ffc107, #ff8c00);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        
        /* The "Photo Integration" look */
        /* This shadow makes the text look like it's cut out or sitting on the image */
        filter: drop-shadow(2px 4px 6px rgba(0,0,0,0.3));
        
        transition: transform 0.3s ease, filter 0.3s ease;
        display: inline-block;
    }

    .enroll-now-text:hover {
        transform: scale(1.05);
        filter: drop-shadow(4px 8px 12px rgba(0,0,0,0.5));
        -webkit-text-fill-color: #ffc107; /* Fallback/Solid color on hover if desired */
    }
</style>

    </div>
</section>

    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Anahaway National High School</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="site-header">
        <div class="container top-bar">
            <div class="brand">
                <i class="fas fa-university logo-icon"></i>
                <div class="brand-text">
                    <h1>Anahaway National High School</h1>
                    <span>Excellence in Education</span>
                </div>
            </div>
            <div class="header-actions">
                <div class="social-links">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>   
            </div>
        </nav>
    </header>

    <main class="container">
        <section class="contact-hero">
            <div class="hero-content">
                <div class="hero-badge">
                    <i class="fas fa-school"></i>
                    <span>Official Contact Channel</span>
                </div>
                <h2 class="display-title">CONTACT <span class="text-accent">US</span></h2>
            </div>
            <div class="hero-visual">
                <div class="image-overlay"></div>
                <img src="https://scontent.fceb6-1.fna.fbcdn.net/v/t39.30808-6/592747727_3233879870098125_8226139278636791208_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=100&ccb=1-7&_nc_sid=dd6889&_nc_eui2=AeHCzD82IevwwHKAhlXdrlvqPeNRF0i0-XA941EXSLT5cMUwO2I9TYrdXsIiI0mOcrsT80BJwY8lrxS_5pFmePpQ&_nc_ohc=Pjtqa3lBRgIQ7kNvwHTLgdQ&_nc_oc=AdlHHz77WnDaADkFDkB_KSrGKkRcfOuJzvsXAgnfe6kIp5o4cXTkhJrfD638uJT9EMo&_nc_zt=23&_nc_ht=scontent.fceb6-1.fna&_nc_gid=E3nw8yYn5rfhHZiVGZkWHA&oh=00_Afue24hSlOS3xlCZ-QMd7RrWCLAvhUUeTZIccXu74BIzbQ&oe=699C48C4" alt="ANHS teachers and faculty">
            <hr></div>
            <br>
        </section>

        <div class="container contact-section">
        <div class="row g-4">
            
            <div class="col-lg-4">
                <div class="contact-card">
                    <div class="form-header text-center">
                        <h4 class="mb-0">Send a Message</h4>
                    </div>
                    <div class="p-4">
                        <form id="contactForm" action="process_contact.php" method="POST">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Full Name</label>
                                <input type="text" class="form-control" name="name" placeholder="cute ako" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email Address</label>
                                <input type="email" class="form-control" name="email" placeholder="oo gad" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Subject</label>
                                <select class="form-select" name="subject">
                                    <option selected>General Inquiry</option>
                                    <option>Enrollment Assistance</option>
                                    <option>Document Request</option>
                                    <option>Technical Support</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-semibold">Message</label>
                                <textarea class="form-control" name="message" rows="5" placeholder="How can we help you today?"></textarea>
                            </div>
                            <button type="submit" class="btn btn-accent w-100">Submit Inquiry</button>
                        </form>
                    </div>
                </div>

                <div class="qr-card mt-4">
                    <div class="bg-light p-2 rounded">
                        <i class="fas fa-qrcode fa-3x text-secondary"></i>
                    </div>
                    <div>
                        <p class="mb-0 fw-bold">Mobile Access</p>
                        <small class="text-muted">Scan to access the Student Portal on your phone.</small>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <div class="info-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <div>
                                <h6>School Campus</h6>
                                <p class="small text-muted mb-0">National Highway, Brgy. Anahaway, Palo, Leyte, Philippines</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item">
                            <i class="fas fa-phone-alt"></i>
                            <div>
                                <h6>Direct Contact</h6>
                                <p class="small text-muted mb-0">Phone: (053) 123-4567<br>Mobile: +63 912 345 6789</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item">
                            <i class="fas fa-envelope-open-text"></i>
                            <div>
                                <h6>Official Email</h6>
                                <p class="small text-muted mb-0">registrar@anahaway.edu.ph<br>info@anahaway.edu.ph</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-item">
                            <i class="fas fa-clock"></i>
                            <div>
                                <h6>Office Hours</h6>
                                <p class="small text-muted mb-0">Monday — Friday<br>8:00 AM – 5:00 PM</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="map-container mb-4">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3913.435728561763!2d124.9537!3d11.156!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTHCsDA5JzIxLjYiTiAxMjTCsDU3JzEzLjMiRQ!5e0!3m2!1sen!2sph!4v1700000000000" 
                        width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>

                <div class="card p-4 border-0 shadow-sm">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <div class="bg-primary text-white rounded-circle p-2 px-3">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <h5 class="mb-0">Help Us Improve</h5>
                    </div>
                    <p class="small text-muted">We value your feedback. Tell us about your experience or suggest improvements to our system.</p>
                    <div class="input-group">
                        <textarea class="form-control" placeholder="Your suggestions..."></textarea>
                        <button class="btn btn-dark px-4">Submit</button>
                    </div>
                </div>
            </div>

        </div>
    </div>


    </main>

<?php 
    include 'nav/footer.php';
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>