<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anahaway National High School | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

/* =====================================================
   GLOBAL STYLES
===================================================== */
body {
    font-family: 'Segoe UI', sans-serif;
}

/* =====================================================
   NAVBAR
===================================================== */
.navbar {
    background: #1f2937;
}

.navbar-brand {
    font-weight: 600;
    color: #fff !important;
}

.nav-link {
    color: #e5e7eb !important;
    font-weight: 500;
}

.nav-link:hover {
    color: #f97316 !important;
}

/* =====================================================
   HERO SECTION
===================================================== */
.hero-section {
    min-height: 90vh;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url('../img/image.png') center/cover no-repeat;
    padding: 120px 0;
}

.hero-section h1 {
    font-size: 3rem;
}

.hero-section p {
    font-size: 1.2rem;
    color: #f3f4f6;
}

.hero-section .btn-warning {
    border-radius: 30px;
}

.hero-section .btn-outline-light {
    border-radius: 30px;
}


/* =====================================================
   BUTTONS
===================================================== */
.btn-primary {
    background: #f97316;
    border: none;
}

.btn-primary:hover {
    background: #ea580c;
}

/* =====================================================
   FEATURES SECTION
===================================================== */
.feature-card {
    border: none;
    transition: 0.3s;
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

/* =====================================================
   TESTIMONIAL SECTION
===================================================== */
.testimonial-section {
    background-color: #f8f9fa;
}

.testimonial-card {
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
    transition: 0.3s ease;
}

.testimonial-card:hover {
    transform: translateY(-4px);
}

.testimonial-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background-color: #1f2937;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* =====================================================
   SCHOOL HIGHLIGHTS
===================================================== */
.school-highlights {
    background-color: #ffffff;
}

.highlight-card {
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    transition: 0.3s ease;
}

.highlight-card:hover {
    transform: translateY(-5px);
}

.highlight-img {
    width: 100%;
    height: 220px;
    object-fit: cover;
}

.read-more {
    text-decoration: none;
    font-weight: 500;
    font-size: 14px;
    color: #1f2937;
}

.read-more:hover {
    color: #000;
}

/* =====================================================
   PREMIUM ATTRACTIVE FOOTER
===================================================== */
.footer-section {
    position: relative;
    padding: 80px 0 30px;

    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url('../img/anhs1.jpg') center/cover no-repeat;

    color: #e2e8f0;
    overflow: hidden;
}

/* Soft glowing accents */
.footer-section::before {
    content: "";
    position: absolute;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(249,115,22,0.3), transparent 70%);
    top: -150px;
    right: -100px;
    filter: blur(80px);
}

.footer-section::after {
    content: "";
    position: absolute;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(59,130,246,0.25), transparent 70%);
    bottom: -120px;
    left: -100px;
    filter: blur(80px);
}

.footer-section .container {
    position: relative;
    z-index: 2;
}

/* Brand */
.footer-brand {
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 15px;
    font-size: 20px;
}

.footer-description {
    font-size: 14px;
    opacity: 0.85;
    line-height: 1.7;
}

/* Section titles */
.footer-title {
    color: #ffffff;
    font-weight: 600;
    margin-bottom: 18px;
    position: relative;
}

/* Accent underline */
.footer-title::after {
    content: "";
    display: block;
    width: 40px;
    height: 3px;
    background: #f97316;
    margin-top: 6px;
    border-radius: 3px;
}

/* Links */
.footer-links li {
    margin-bottom: 10px;
}

.footer-links a {
    text-decoration: none;
    color: #cbd5e1;
    font-size: 14px;
    transition: all 0.3s ease;
}

.footer-links a:hover {
    color: #ffffff;
    padding-left: 6px;
}

/* Contact */
.footer-contact {
    font-size: 14px;
    margin-bottom: 10px;
    opacity: 0.9;
}

/* Divider */
.footer-divider {
    margin: 40px 0 20px;
    border-color: rgba(255,255,255,0.15);
}

/* Bottom */
.footer-bottom {
    font-size: 13px;
    opacity: 0.8;
}


</style>

</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top shadow-sm">
    <div class="container">

        <!-- Logo + School Name -->
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWzjUEQ1sCA6A1bnpVoojVV7zNi7vdyYpXfA&s"
                 alt="ANHS Logo"
                 class="rounded-circle"
                 width="45"
                 height="45"
                 style="object-fit: cover;">
            <div class="d-flex flex-column">
                <span class="fw-bold fs-5">Anahaway National High School</span>
                <small class="text-warning" style="font-size: 12px;">Education turns potential into power</small>
            </div>
        </a>

        <!-- Mobile Toggle -->
        <button class="navbar-toggler border-0" type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu -->
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="#">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="#">About</a>
                </li>


                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#">Programs</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="#">Courses</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#">Admissions</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="#">Contact</a>
                </li>

                <li class="nav-item">
                    <a class="btn btn-warning px-4 fw-semibold ms-lg-3"
                       href="#"
                       style="border-radius: 30px;">
                        Admin
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>


<!-- HERO SECTION -->
<section class="hero-section d-flex align-items-center text-white text-center">
    <div class="container position-relative">

        <h1 class="display-4 fw-bold mb-3">
            Welcome to Anahaway National High School
        </h1>

        <p class="lead mb-4 col-lg-8 mx-auto">
            Empowering students through quality education, innovation,
            leadership, and a modern Enrollment Management System.
        </p>

        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="#" class="btn btn-warning btn-lg px-4 fw-semibold">
                Apply Now
            </a>

            <a href="#" class="btn btn-outline-light btn-lg px-4 fw-semibold">
                Learn More
            </a>
        </div>

    </div>
</section>


<!-- FEATURES -->
<section class="py-5">
    <div class="container text-center">
        <h2 class="section-title mb-5">What We Offer</h2>
        <div class="row g-4">

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-user-graduate fa-3x text-primary mb-3"></i>
                    <h5>Certified Teachers</h5>
                    <p>Highly qualified educators committed to excellence.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-book-open fa-3x text-primary mb-3"></i>
                    <h5>Modern Curriculum</h5>
                    <p>Industry-aligned programs designed for success.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-building-columns fa-3x text-primary mb-3"></i>
                    <h5>Advanced Facilities</h5>
                    <p>Smart classrooms and modern learning tools.</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card feature-card p-4">
                    <i class="fa-solid fa-futbol fa-3x text-primary mb-3"></i>
                    <h5>Sports & Clubs</h5>
                    <p>Holistic development through extracurricular activities.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ABOUT SECTION -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">About Our School</h2>
                <p>
                    Anahaway National High School is dedicated to providing quality
                    education and shaping future leaders through innovation and
                    excellence.
                </p>
                <a href="#" class="btn btn-primary">Learn More</a>
            </div>
            <div class="col-md-6 text-center">
                <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7"
                     class="img-fluid rounded shadow" alt="School">
            </div>
        </div>
    </div>
</section>

<!-- CTA SECTION -->
<section class="py-5 text-center">
    <div class="container">
        <h2 class="section-title">Ready to Enroll?</h2>
        <p class="lead">Start your journey with us today.</p>
        <a href="#" class="btn btn-primary btn-lg">Apply for Admission</a>
    </div>
</section>

<!-- SCHOOL OVERVIEW -->
<section class="py-5 bg-light border-top">
    <div class="container">
        <div class="row align-items-center mb-5">

            <!-- Image -->
            <div class="col-md-4 mb-4 mb-md-0">
                <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7"
                     class="img-fluid rounded shadow-sm"
                     alt="School Image">
            </div>

            <!-- Description -->
            <div class="col-md-8">
                <h3 class="fw-bold">Anahaway National High School</h3>
                <p class="text-muted">
                    Anahaway National High School provides quality secondary education
                    focused on academic excellence, leadership development, and
                    holistic student growth.
                </p>

                <!-- Stats -->
                <div class="row text-center mt-4 g-3">

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">18</h2>
                            <small class="text-muted">Certified Teachers</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">43</h2>
                            <small class="text-muted">Students</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">10</h2>
                            <small class="text-muted">Courses</small>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="p-3 border rounded bg-white shadow-sm">
                            <h2 class="fw-bold text-primary mb-0">50</h2>
                            <small class="text-muted">Awards Won</small>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- COURSES -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Courses</h2>
            <p class="text-muted">
                Explore our academic programs designed to equip students with
                knowledge, skills, and leadership excellence.
            </p>
        </div>

        <div class="row g-4">

            <!-- Course Card -->
            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card h-100 shadow-sm border-0 course-card">
                    <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644"
                         class="card-img-top"
                         style="height:180px; object-fit:cover;"
                         alt="Course">

                    <div class="card-body text-center">
                        <h5 class="fw-bold">Course <?php echo $i; ?></h5>
                        <p class="text-muted small">
                            Comprehensive curriculum designed to build
                            strong academic foundations.
                        </p>
                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Apply Now
                        </a>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- CERTIFIED TEACHERS -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Certified Teachers</h2>
            <p class="text-muted">
                Our faculty members are highly trained professionals
                committed to delivering quality education.
            </p>
        </div>

        <div class="row g-4">

            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card text-center shadow-sm border-0 teacher-card">
                    <img src="https://randomuser.me/api/portraits/men/<?php echo rand(10,99); ?>.jpg"
                         class="rounded-circle mx-auto mt-4"
                         width="100"
                         height="100"
                         style="object-fit:cover;"
                         alt="Teacher">

                    <div class="card-body">
                        <h6 class="fw-bold mb-1">Teacher Name</h6>
                        <small class="text-muted">Subject Specialist</small>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- TEACHERS + REQUEST QUOTE SECTION -->
<section class="py-5 border-top">
    <div class="container">

        <!-- Section Title -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Certified Teachers</h2>
            <p class="text-muted">
                Meet our professional educators dedicated to student success.
            </p>
        </div>

        <!-- Teachers Row -->
        <div class="row g-4 mb-5">

            <?php for($i=1; $i<=4; $i++): ?>
            <div class="col-md-3">
                <div class="card shadow-sm border-0 text-center h-100">
                    <img src="https://randomuser.me/api/portraits/men/<?php echo rand(10,99); ?>.jpg"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Teacher">

                    <div class="card-body">
                        <h6 class="fw-bold mb-1">Teacher Name <?php echo $i; ?></h6>
                        <small class="text-muted d-block mb-2">Subject Specialist</small>
                        <p class="small text-muted">
                            Dedicated educator with experience in modern teaching strategies.
                        </p>
                    </div>
                </div>
            </div>
            <?php endfor; ?>

        </div>

        <!-- Request Quote Section -->
        <div class="row align-items-center bg-light p-4 rounded shadow-sm">

            <!-- Image -->
            <div class="col-md-6 mb-4 mb-md-0">
                <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7"
                     class="img-fluid rounded"
                     alt="School">
            </div>

            <!-- Form -->
            <div class="col-md-6">
                <h3 class="fw-bold mb-3">Request Information</h3>
                <p class="text-muted small">
                    Fill out the form below and we will get back to you shortly.
                </p>

                <form>
                    <div class="row g-3">

                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="First Name">
                        </div>

                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="Last Name">
                        </div>

                        <div class="col-12">
                            <select class="form-select">
                                <option selected>Select Course</option>
                                <option>Science</option>
                                <option>Mathematics</option>
                                <option>English</option>
                                <option>Technology</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <input type="email" class="form-control" placeholder="Email Address">
                        </div>

                        <div class="col-12">
                            <button class="btn btn-warning w-100 fw-semibold">
                                Request Information
                            </button>
                        </div>

                    </div>
                </form>

            </div>

        </div>

    </div>
</section>

<!-- UPCOMING EVENTS -->
<section class="py-5 bg-light border-top">
    <div class="container">

        <!-- Section Header -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Upcoming <span class="text-primary">Events</span></h2>
            <p class="text-muted">
                Stay connected with campus life. Join our upcoming events, workshops, and activities.
            </p>
        </div>

        <!-- Events Row -->
        <div class="row g-4">

            <!-- Event 1 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://images.unsplash.com/photo-1515169067868-5387ec356754"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">15</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">10:00 AM - 4:00 PM</small>
                                <h6 class="fw-bold mt-1">Spring Open House</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Join us for a campus tour and discover our academic programs and facilities.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

            <!-- Event 2 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://images.unsplash.com/photo-1503428593586-e225b39bddfe"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">22</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">2:00 PM - 5:00 PM</small>
                                <h6 class="fw-bold mt-1">Research Symposium</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Students showcase innovative research projects and academic achievements.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

            <!-- Event 3 -->
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 event-card">
                    <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d"
                         class="card-img-top"
                         style="height:200px; object-fit:cover;"
                         alt="Event">

                    <div class="card-body">

                        <div class="d-flex align-items-start mb-3">
                            <div class="me-3 text-center border-end pe-3">
                                <h4 class="fw-bold text-primary mb-0">28</h4>
                                <small class="text-muted">March</small>
                            </div>
                            <div>
                                <small class="text-muted">6:00 PM - 9:00 PM</small>
                                <h6 class="fw-bold mt-1">Alumni Networking Night</h6>
                            </div>
                        </div>

                        <p class="text-muted small">
                            Connect with alumni and expand professional opportunities.
                        </p>

                        <a href="#" class="btn btn-warning w-100 fw-semibold">
                            Learn More...
                        </a>

                    </div>
                </div>
            </div>

        </div>

        <!-- View All Button -->
        <div class="text-center mt-5">
            <a href="#" class="btn btn-primary px-4 fw-semibold">
                View All Events
            </a>
        </div>

    </div>
</section>

<!-- RECENT BLOG -->
<section class="py-5 border-top">
    <div class="container">

        <!-- Section Header -->
        <div class="text-center mb-5">
            <h2 class="fw-bold">Recent <span class="text-dark">Blog</span></h2>
            <p class="text-muted">
                Stay updated with our latest news, articles, and school updates.
            </p>
        </div>

        <div class="row g-4">

            <?php for($i=1; $i<=3; $i++): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 blog-card">

                    <!-- Blog Image -->
                    <div class="position-relative">
                        <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644"
                             class="card-img-top"
                             style="height:220px; object-fit:cover;"
                             alt="Blog Image">

                        <!-- Date Badge -->
                        <div class="position-absolute top-0 start-0 bg-warning text-white text-center p-2"
                             style="width:70px;">
                            <h6 class="mb-0 fw-bold">26</h6>
                            <small>Feb</small><br>
                            <small>2026</small>
                        </div>
                    </div>

                    <!-- Blog Content -->
                    <div class="card-body text-center">
                        <h6 class="fw-bold">Skills To Develop Your Child Memory</h6>
                        <p class="text-muted small">
                            Discover practical techniques and school-supported activities
                            that help improve memory retention and learning skills.
                        </p>

                        <a href="#" class="btn btn-warning px-4 fw-semibold">
                            Learn More...
                        </a>
                    </div>

                </div>
            </div>
            <?php endfor; ?>

        </div>
    </div>
</section>

<!-- TESTIMONIAL SECTION -->
<section class="testimonial-section py-5">
    <div class="container">

        <!-- Header -->
        <div class="text-center mb-4">
            <h2 class="fw-bold">What Our Students & Parents Say</h2>
            <p class="text-muted col-lg-8 mx-auto">
                We value the voices of our students and parents.
                Their experiences reflect our commitment to academic excellence,
                discipline, and holistic development.
            </p>
        </div>

        <!-- Testimonials -->
        <div class="row g-4 justify-content-center">

            <!-- Student -->
            <div class="col-md-5">
                <div class="testimonial-card p-4 h-100">
                    <div class="quote-icon mb-3">“</div>

                    <p class="testimonial-text">
                        Anahaway National High School provides a supportive
                        learning environment where students are encouraged
                        to grow academically and personally. The teachers
                        are dedicated and approachable.
                    </p>

                    <div class="d-flex align-items-center mt-4">
                        <div class="testimonial-avatar me-3">
                            <i class="fa-solid fa-user text-white"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-semibold">Juan Dela Cruz</h6>
                            <small class="text-muted">Grade 12 Student</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Parent -->
            <div class="col-md-5">
                <div class="testimonial-card p-4 h-100">
                    <div class="quote-icon mb-3">“</div>

                    <p class="testimonial-text">
                        As a parent, I am confident in the quality of education
                        my child receives. The school maintains strong values,
                        discipline, and a structured enrollment system.
                    </p>

                    <div class="d-flex align-items-center mt-4">
                        <div class="testimonial-avatar me-3">
                            <i class="fa-solid fa-user text-white"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-semibold">Maria Santos</h6>
                            <small class="text-muted">Parent</small>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- SCHOOL HIGHLIGHTS -->
<section class="school-highlights py-5">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">School Highlights</h2>
            <p class="text-muted">
                Stay updated with the latest news, events, and announcements.
            </p>
        </div>

        <div class="row g-4">

            <!-- Highlight 1 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://images.unsplash.com/photo-1588072432836-e10032774350"
                         class="img-fluid highlight-img"
                         alt="Students in classroom">

                    <div class="p-4">
                        <h6 class="fw-semibold">Enrollment Now Open</h6>
                        <p class="text-muted small">
                            Online enrollment for School Year 2026–2027
                            is now available through our EMS portal.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

            <!-- Highlight 2 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7"
                         class="img-fluid highlight-img"
                         alt="Award ceremony">

                    <div class="p-4">
                        <h6 class="fw-semibold">Academic Excellence Award</h6>
                        <p class="text-muted small">
                            Congratulations to our honor students for
                            achieving outstanding academic performance.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

            <!-- Highlight 3 -->
            <div class="col-md-4">
                <div class="highlight-card">
                    <img src="https://images.unsplash.com/photo-1523580494863-6f3031224c94"
                         class="img-fluid highlight-img"
                         alt="School community activity">

                    <div class="p-4">
                        <h6 class="fw-semibold">Community Outreach Program</h6>
                        <p class="text-muted small">
                            Students participated in our annual outreach
                            program promoting leadership and service.
                        </p>
                        <a href="#" class="read-more">Read More →</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<!-- =====================================================
     PREMIUM ATTRACTIVE FOOTER
===================================================== -->
<footer class="footer-section">
    <div class="container">

        <div class="row gy-5">

            <!-- School Info -->
            <div class="col-md-4">
                <h5 class="footer-brand">
                    Anahaway National High School
                </h5>
                <p class="footer-description">
                    Empowering students through academic excellence,
                    leadership, and innovation with our modern
                    Enrollment Management System.
                </p>
            </div>

            <!-- Quick Links -->
            <div class="col-md-2">
                <h6 class="footer-title">Quick Links</h6>
                <ul class="footer-links list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Programs</a></li>
                    <li><a href="#">Admissions</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>

            <!-- System -->
            <div class="col-md-3">
                <h6 class="footer-title">System Access</h6>
                <ul class="footer-links list-unstyled">
                    <li><a href="#">Student Portal</a></li>
                    <li><a href="#">Teacher Portal</a></li>
                    <li><a href="#">Admin Login</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div class="col-md-3">
                <h6 class="footer-title">Contact</h6>
                <p class="footer-contact">
                    <i class="fa-solid fa-location-dot me-2"></i>
                    Lopez Jaena, Misamis Occidental
                </p>
                <p class="footer-contact">
                    <i class="fa-solid fa-phone me-2"></i>
                    (000) 000-0000
                </p>
                <p class="footer-contact">
                    <i class="fa-solid fa-envelope me-2"></i>
                    info@anahawaynhs.edu.ph
                </p>
            </div>

        </div>

        <hr class="footer-divider">

        <!-- Bottom -->
        <div class="text-center footer-bottom">
            © <?php echo date('Y'); ?> Anahaway National High School |
            Enrollment Management System. All Rights Reserved.
        </div>

    </div>
</footer>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
